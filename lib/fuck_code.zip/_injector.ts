import { Provider } from '../provider';
import { _NullInjector, _THROW_IF_NOT_FOUND } from './_null-injector';
import { Injector } from './injector';

/**
 * 这里定义Injector的基础接口
 */
export abstract class _Injector {
  /**
   * 根据token实例化和获取instance
   * 如果没有找到考虑初始化
   */
  abstract get<T>(token: Type<T> | InjectionToken<T>, notFoundValue?: T): T;

  /**
   * @deprecated from v4.0.0 use Type<T> or InjectionToken<T>
   * @suppress {duplicate}
   */
  abstract get(token: any, notFoundValue?: any): any;
}
